#!/bin/bash

python3 run_simulation.py --experiment a --init 2
python3 run_simulation.py --experiment a --init 1
python3 run_simulation.py --experiment b --init 2
python3 run_simulation.py --experiment b --init 1
python3 run_simulation.py --experiment c --init 2
python3 run_simulation.py --experiment c --init 1
python3 run_simulation.py --experiment e --init 2
python3 run_simulation.py --experiment e --init 1
python3 run_simulation.py --experiment f --init 2
python3 run_simulation.py --experiment f --init 1

